import { Component } from '@angular/core';

@Component({
  selector: 'app-hotel',
  imports: [],
  templateUrl: './hotel.component.html',
  styleUrl: './hotel.component.css'
})
export class HotelComponent {

}
