import { Component } from '@angular/core';

@Component({
  selector: 'app-cabs',
  imports: [],
  templateUrl: './cabs.component.html',
  styleUrl: './cabs.component.css'
})
export class CabsComponent {

}
